// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compact to bottommost\n", stdout);
  return lionss_run_workload("rocksdbCompact");
}
