// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate rowan moor"); }
int main(){
  announce();
  return lionss_run_workload("RowanMoor");
}
