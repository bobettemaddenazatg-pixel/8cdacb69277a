// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evaluate scale-up\n", stdout);
  return lionss_run_workload("hpa_scaleup");
}
